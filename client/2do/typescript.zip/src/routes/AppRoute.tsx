import React from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import ForgotPassword from "../pages/Auth/ForgotPassword/ForgotPassword";
import Login from "../pages/Auth/Login/Login";
import ResetPassword from "../pages/Auth/ResetPassword/ResetPassword";
import ResetPasswordSuccess from "../pages/Auth/ResetPassword/ResetPasswordSuccess";
import SignUp from "../pages/Auth/SignUp/SignUp";
import Task from "../pages/Task/Task";
import AddEditTask from "../pages/Task/AddEditTask/AddEditTask";
import Category from "../pages/Category/Category";
import Profile from "../pages/Profile/Profile";
import NotFound from "../components/NotFound/NotFound";
import Checklist from "../pages/Checklist/Checklist";
import AddEditChecklist from "../pages/Checklist/AddEditChecklist/AddEditChecklist";
import RequireAuth from "../components/RequireAuth/RequireAuth";
import { ROUTES } from "../utils/constants";
import VerifyEmail from "../pages/Auth/VerifyEmail/VerifyEmail";

const AppRoute = () => {
  return (
    <>
      <Routes>
        <Route path="/" element={<Navigate to={`/${ROUTES.LOGIN}`} replace />} />
        <Route
          path={`/${ROUTES.LOGIN}`}
          element={
            <RequireAuth moduleName={"auth"}>
              <Login />
            </RequireAuth>
          }
        />
        <Route
          path={`/${ROUTES.SIGNUP}`}
          element={
            <RequireAuth moduleName={"auth"}>
              <SignUp />
            </RequireAuth>
          }
        />
        <Route
          path={`/${ROUTES.FORGOT_PASSWORD}`}
          element={
            <RequireAuth moduleName={"auth"}>
              <ForgotPassword />
            </RequireAuth>
          }
        />
        <Route
          path={`/${ROUTES.RESET_PASSWORD}`}
          element={
            <RequireAuth moduleName={"auth"}>
              <ResetPassword />
            </RequireAuth>
          }
        />
        <Route
          path={`/${ROUTES.RESET_PASSWORD_SUCCESS}`}
          element={
            <RequireAuth moduleName={"auth"}>
              <ResetPasswordSuccess />
            </RequireAuth>
          }
        />
        <Route
          path={`/${ROUTES.CATEGORY}`}
          element={
            <RequireAuth>
              <Category />
            </RequireAuth>
          }
        />
        <Route
          path={`/${ROUTES.PROFILE}`}
          element={
            <RequireAuth>
              <Profile />
            </RequireAuth>
          }
        />
        <Route path={`/${ROUTES.VERIFY_EMAIL}`} element={<VerifyEmail />} />
        <Route
          path={`/${ROUTES.TASK}`}
          element={
            <RequireAuth>
              <Task />
            </RequireAuth>
          }
        />
        <Route
          path={`/${ROUTES.TASK}/${ROUTES.ADD_EDIT_TASK}`}
          element={
            <RequireAuth>
              <AddEditTask />
            </RequireAuth>
          }
        />
        <Route
          path={`/${ROUTES.CHECKLIST}`}
          element={
            <RequireAuth>
              <Checklist />
            </RequireAuth>
          }
        />
        <Route
          path={`/${ROUTES.CHECKLIST}/${ROUTES.ADD_EDIT_CHECKLIST}`}
          element={
            <RequireAuth>
              <AddEditChecklist />
            </RequireAuth>
          }
        />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
};

export default AppRoute;
