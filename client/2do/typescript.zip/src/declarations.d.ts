declare module "*.woff2" {
  const src: string;
  export default src;
}
