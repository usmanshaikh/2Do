import { API_PATHS } from "./apiPaths";
import { MESSAGES } from "./messages";
import { ROUTE_PATHS } from "./routePaths";

export { API_PATHS as API, MESSAGES as MSG, ROUTE_PATHS as ROUTES };
