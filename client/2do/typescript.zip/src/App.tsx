import { Box } from "@mui/material";
import AppRoute from "./routes/AppRoute";
import Layout from "./components/Layout/Layout";
import { useAxiosInterceptor } from "./hooks";
import "./App.scss";

const App = () => {
  const isLoaded = useAxiosInterceptor();

  if (!isLoaded) return <div>Loading...</div>;

  return (
    <Box className="App">
      <Layout>
        <AppRoute />
      </Layout>
    </Box>
  );
};

export default App;
