import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { useGlobalContext } from "../hooks";
import { getLocalAccessToken, setLocalAccessToken, setLocalRefreshToken, getLocalRefreshToken } from "../utils/helpers";
import { authApi } from "../api";
import { ROUTES } from "../utils/constants";

const NO_LOADER = { headers: { noLoader: true } };

const axiosInstance = axios.create({
  baseURL: "http://ec2-3-108-252-93.ap-south-1.compute.amazonaws.com:3000/v1/",
  headers: { "Content-Type": "application/json" },
});

const useAxiosInterceptor = () => {
  const { setShowLoaderHandler, setAuthenticateHandler } = useGlobalContext();
  const [isLoaded, setIsLoaded] = useState(false);
  const navigate = useNavigate();

  // Manage token refreshing and loader requests
  let isRefreshing = false;
  const refreshSubscribers: Array<(token: string) => void> = [];
  const requestQueue: Record<number, any> = {};
  let requestCounter = 0;

  const onRefreshed = (token: string) => {
    refreshSubscribers.forEach((cb) => cb(token));
    refreshSubscribers.length = 0;
  };

  const addRequest = (config: any) => {
    const requestId = ++requestCounter;
    requestQueue[requestId] = config;
    return requestId;
  };

  const removeRequest = (id: number) => {
    delete requestQueue[id];
    if (Object.keys(requestQueue).length === 0) {
      setShowLoaderHandler(false);
    }
  };

  const requestInterceptor = (config: any) => {
    if (!config.headers.noLoader) {
      setShowLoaderHandler(true);
      config.requestId = addRequest(config);
    }

    const token = getLocalAccessToken();
    if (token) config.headers["Authorization"] = `Bearer ${token}`;
    return config;
  };

  const responseInterceptor = (response: any) => {
    if (response.config.requestId) removeRequest(response.config.requestId);
    return response.data;
  };

  const handleRefreshToken = (errorConfig: any) => {
    if (!isRefreshing) {
      isRefreshing = true;
      const refreshToken = getLocalRefreshToken();
      return authApi
        .refreshTokens({ refreshToken })
        .then(({ data }) => {
          isRefreshing = false;
          setLocalAccessToken(data.access.token);
          setLocalRefreshToken(data.refresh.token);
          onRefreshed(data.access.token);
          return data.access.token;
        })
        .catch(() => {
          isRefreshing = false;
          handleLogout();
        });
    }

    return new Promise((resolve) => {
      refreshSubscribers.push((token: string) => {
        errorConfig.headers["Authorization"] = `Bearer ${token}`;
        resolve(axiosInstance(errorConfig));
      });
    });
  };

  const responseErrorInterceptor = async (error: any) => {
    if (error.config.requestId) removeRequest(error.config.requestId);

    const { config, response } = error;
    if (response?.status === 401 && !config.url.includes("auth/")) {
      return handleRefreshToken(config);
    }

    return Promise.reject(error.response?.data || error);
  };

  const handleLogout = () => {
    localStorage.clear();
    setAuthenticateHandler(false);
    navigate(`/${ROUTES.LOGIN}`);
  };

  useEffect(() => {
    const reqInterceptor = axiosInstance.interceptors.request.use(requestInterceptor, Promise.reject);
    const resInterceptor = axiosInstance.interceptors.response.use(responseInterceptor, responseErrorInterceptor);

    setIsLoaded(true);
    return () => {
      axiosInstance.interceptors.request.eject(reqInterceptor);
      axiosInstance.interceptors.response.eject(resInterceptor);
    };
  }, []);

  return isLoaded;
};

export { useAxiosInterceptor, axiosInstance as axios, NO_LOADER };
