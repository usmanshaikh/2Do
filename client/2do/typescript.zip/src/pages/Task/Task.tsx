import { useEffect, useState } from "react";
import { createSearchParams, useLocation, useNavigate } from "react-router-dom";
import { Box } from "@mui/material";
import { taskApi } from "../../api";
import { TaskCard } from "../../components/Cards";
import { MSG, ROUTES } from "../../utils/constants";
import NoDataFound from "../../components/NoDataFound/NoDataFound";
import "./Task.scss";
import { useAppDispatch, useAppSelector } from "../../hooks";
import { showSnackbar } from "../../store/slices";

const Task = () => {
  const filter = useAppSelector((state) => state.filter);
  const [tasks, setTasks] = useState<any>([]);
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useAppDispatch();

  useEffect(() => {
    filter.selectedCategory?.id && fetchTasks();
  }, [filter]);

  const fetchTasks = async () => {
    const payload = {
      category: filter.selectedCategory?.id,
      isCompleted: filter.selectedStatus?.isCompleted,
    };
    try {
      const res = await taskApi.allTasks(payload);
      setTasks(res);
    } catch (err) {
      setTasks([]);
    }
  };

  const toggleTaskCompletion = (task) => {
    const updatedTask = { ...task, isCompleted: !task.isCompleted };
    return updatedTask;
  };

  const handleTaskStatusChange = async (task) => {
    const updatedTask = toggleTaskCompletion(task);
    const payload = { isCompleted: updatedTask.isCompleted };
    const taskId = task.id;

    try {
      const res: any = await taskApi.changeTaskStatus(payload, taskId);
      const index = tasks.findIndex((item) => item.id === res.id);
      if (index !== -1) {
        setTasks((prevTasks) => {
          const newTasks = [...prevTasks];
          newTasks[index] = updatedTask;
          return newTasks;
        });
      }
      dispatch(
        showSnackbar({
          message: `${MSG.USER_FEEDBACK.TASK.STATUS_CHANGED} ${updatedTask.isCompleted ? "completed" : "pending"}.`,
          type: "info",
        })
      );
    } catch (err) {
      dispatch(
        showSnackbar({
          message: err.message,
          type: "error",
        })
      );
    }
  };

  const handleTaskDeletion = async (task) => {
    const taskId = task.id;
    try {
      await taskApi.deleteTask(taskId);
      setTasks((prevTasks) => prevTasks.filter((item) => item.id !== taskId));
      dispatch(
        showSnackbar({
          message: MSG.USER_FEEDBACK.TASK.DELETED,
          type: "info",
        })
      );
    } catch (err) {
      dispatch(
        showSnackbar({
          message: MSG.USER_FEEDBACK.VERIFICATION_LINK_SENT,
          type: "error",
        })
      );
    }
  };

  const handleTaskEdit = (task) => {
    navigate({
      pathname: `${location.pathname}/${ROUTES.ADD_EDIT_TASK}`,
      search: createSearchParams({ taskId: task.id, edit: "true" }).toString(),
    });
  };

  return (
    <>
      <Box className="taskPageWrapper">
        {tasks.length ? (
          <TaskCard
            tasks={tasks}
            changeStatus={handleTaskStatusChange}
            deleteTask={handleTaskDeletion}
            editTask={handleTaskEdit}
          />
        ) : (
          <NoDataFound />
        )}
      </Box>
    </>
  );
};

export default Task;
