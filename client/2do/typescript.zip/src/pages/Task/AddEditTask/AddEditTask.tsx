import { useEffect, useState } from "react";
import * as yup from "yup";
import { useFormik } from "formik";
import { TextField } from "@mui/material";
import { useModal } from "mui-modal-provider";
import { ConfirmationModal, SuccessModal } from "../../../components/Modals";
import { hideFooter, showFooter } from "../../../utils/helpers";
import { taskApi } from "../../../api";
import { useNavigate, useSearchParams } from "react-router-dom";
import { MSG, ROUTES } from "../../../utils/constants";
import ChooseColor from "../../../components/ChooseColor/ChooseColor";
import CustomButton from "../../../components/CustomButton/CustomButton";
import ChooseCategory from "../../../components/ChooseCategory/ChooseCategory";
import SetDateTime from "../../../components/SetDateTime/SetDateTime";
import GetAlert from "../../../components/GetAlert/GetAlert";
import MarkAsComplete from "../../../components/MarkAsComplete/MarkAsComplete";
import "./AddEditTask.scss";

const validationSchema = yup.object({
  description: yup.string().required(MSG.VALIDATION.DESCRIPTION.REQUIRED),
});

const AddEditTask = () => {
  const navigate = useNavigate();
  const [compState, setCompState] = useState<any>({});
  const [searchParams] = useSearchParams();
  const [isEdit, setIsEdit] = useState("false");
  const [task, setTask] = useState<any>();
  const { showModal } = useModal();

  const formik = useFormik({
    initialValues: { description: "" },
    validationSchema: validationSchema,
    onSubmit: () => {
      const initialState = {
        message: MSG.USER_FEEDBACK.TASK.CREATE_CONFIRMATION,
        onConfirm: () => submitFormHandler(),
      };
      showModal(ConfirmationModal, initialState, { destroyOnClose: true });
    },
  });

  useEffect(() => {
    resetAllData();
    checkIfEdit();
  }, [searchParams]);

  const resetAllData = () => {
    // Because we are using same component so manually resetting the component
    setTask(null);
    setCompState(null);
    formik.setFieldValue("description", "");
  };

  const checkIfEdit = () => {
    const taskId = searchParams.get("taskId");
    const isEdit = searchParams.get("edit");
    let isEditBoolean;
    if (isEdit === "true") isEditBoolean = true;
    else isEditBoolean = false;
    setIsEdit(isEditBoolean);
    isEditBoolean && getTask(taskId);
  };

  const getTask = (taskId) => {
    taskApi.getTask(taskId).then((res: any) => {
      setTask(res);
      const defaultCompValues = {
        title: res.title,
        category: res.category,
        cardColor: res.cardColor,
        dateAndTime: res.dateAndTime,
        alert: res.alert,
        isCompleted: res.isCompleted,
      };
      setCompState(defaultCompValues);
      formik.setFieldValue("description", res.title);
    });
  };

  const updateCompState = (data) => {
    setCompState((prevState) => ({
      ...prevState,
      ...data,
    }));
  };

  const submitFormHandler = () => {
    const taskId = searchParams.get("taskId");
    compState.title = formik.values.description;
    if (isEdit) {
      taskApi.updateTask(compState, taskId).then((res) => {
        const initialState = {
          message: MSG.USER_FEEDBACK.CHANGES_SAVED,
          onClose: () => navigateTo(),
        };
        showModal(SuccessModal, initialState, { destroyOnClose: true });
      });
    } else {
      compState.isCompleted = false;
      taskApi.createTask(compState).then((res) => {
        const initialState = {
          message: MSG.USER_FEEDBACK.TASK.CREATED,
          onClose: () => navigateTo(),
        };
        showModal(SuccessModal, initialState, { destroyOnClose: true });
      });
    }
  };

  const navigateTo = () => {
    navigate(`/${ROUTES.TASK}`);
  };

  const onDeleteHandler = () => {
    const initialState = {
      message: MSG.USER_FEEDBACK.CONFIRMATION_DELETE,
      onConfirm: () => confirmDeleteTaskHandler(),
      type: "danger",
    };
    showModal(ConfirmationModal, initialState, { destroyOnClose: true });
  };

  const confirmDeleteTaskHandler = () => {
    const taskId = searchParams.get("taskId");
    taskApi.deleteTask(taskId).then((res) => {
      const initialState = {
        message: MSG.USER_FEEDBACK.TASK.DELETED,
        onClose: () => navigateTo(),
      };
      showModal(SuccessModal, initialState, { destroyOnClose: true });
    });
  };

  return (
    <>
      {(task || !isEdit) && (
        <div className="addTaskPageWrapper">
          <div className="cardWrapper">
            <div className="formWrapper">
              <form onSubmit={formik.handleSubmit}>
                <div className="commonInputWrap">
                  <span className="commonLabel">description</span>
                  <TextField
                    fullWidth
                    multiline
                    id="description"
                    name="description"
                    autoComplete="off"
                    className="commonInputFormControl"
                    placeholder="Enter Description"
                    value={formik.values.description}
                    onChange={formik.handleChange}
                    onFocus={hideFooter}
                    onBlur={showFooter}
                    error={formik.touched.description && Boolean(formik.errors.description)}
                    helperText={formik.touched.description && formik.errors.description}
                  />
                </div>
                <ChooseCategory
                  isEdit={isEdit}
                  category={task?.category}
                  onChooseCategory={(data) => updateCompState(data)}
                />
                <SetDateTime
                  isEdit={isEdit}
                  dateAndTime={task?.dateAndTime}
                  onSetDateTime={(data) => updateCompState(data)}
                />
                <GetAlert isEdit={isEdit} alert={task?.alert} onAlert={(data) => updateCompState(data)} />
                <ChooseColor
                  isEdit={isEdit}
                  cardColor={task?.cardColor}
                  onChooseColor={(data) => updateCompState(data)}
                />
                {isEdit && (
                  <MarkAsComplete
                    isEdit={isEdit}
                    isCompleted={task?.isCompleted}
                    onChangeStatus={(data) => updateCompState(data)}
                  />
                )}
                {isEdit && <CustomButton name="Delete" color="danger" onClick={onDeleteHandler} />}
                <CustomButton name="Done" color="blue" type="submit" />
              </form>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default AddEditTask;
