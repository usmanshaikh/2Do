import React, { useContext } from "react";
import * as yup from "yup";
import { useFormik } from "formik";
import { Link, useNavigate } from "react-router-dom";
import { TextField } from "@mui/material";
import { authApi } from "../../../api";
import { useGlobalContext } from "../../../hooks";
import { GlobalSnackbarAlertContext } from "../../../utils/contexts";
import { setLocalAccessToken, setLocalRefreshToken } from "../../../utils/helpers";
import { MSG, ROUTES } from "../../../utils/constants";
import CustomButton from "../../../components/CustomButton/CustomButton";
import "../Auth.scss";

const validationSchema = yup.object({
  email: yup.string().email(MSG.VALIDATION.EMAIL.INVALID).required(MSG.VALIDATION.EMAIL.REQUIRED),
  password: yup
    .string()
    .min(MSG.VALIDATION.PASSWORD.MIN_LENGTH, MSG.VALIDATION.PASSWORD.LENGTH_ERROR)
    .required(MSG.VALIDATION.PASSWORD.REQUIRED),
});

const Login = () => {
  const navigate = useNavigate();
  const { setAuthenticateHandler } = useGlobalContext();
  const snackbarAlert = useContext(GlobalSnackbarAlertContext);

  const formik = useFormik({
    initialValues: {
      email: "shaikhusman57@gmail.com",
      password: "test@123",
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      login(values);
    },
  });

  const login = (payload) => {
    authApi
      .login(payload)
      .then((res: any) => {
        const accessToken = res.tokens.access.token;
        const refreshToken = res.tokens.refresh.token;
        setLocalAccessToken(accessToken);
        setLocalRefreshToken(refreshToken);
        setAuthenticateHandler(true);
        navigate(`/${ROUTES.TASK}`);
      })
      .catch((err) => {
        snackbarAlert.showSnackbarAlert({ msg: err.message, type: "error" });
      });
  };

  return (
    <div className="loginPageWrapper commonAuthWrapper">
      <h1 className="heading">Login</h1>
      <span className="subHeading">Hello Again! Welcome back</span>
      <div className="formWrapper">
        <form onSubmit={formik.handleSubmit}>
          <div className="commonInputWrap">
            <TextField
              fullWidth
              variant="standard"
              id="email"
              name="email"
              label="Email"
              autoComplete="off"
              className="commonInputFormControl"
              value={formik.values.email}
              onChange={formik.handleChange}
              error={formik.touched.email && Boolean(formik.errors.email)}
              helperText={formik.touched.email && formik.errors.email}
            />
          </div>
          <div className="commonInputWrap">
            <TextField
              fullWidth
              variant="standard"
              id="password"
              name="password"
              label="Password"
              type="password"
              className="commonInputFormControl"
              value={formik.values.password}
              onChange={formik.handleChange}
              error={formik.touched.password && Boolean(formik.errors.password)}
              helperText={formik.touched.password && formik.errors.password}
            />
          </div>
          <div className="forgotLinkWrap">
            <Link className="aLink" to={`/${ROUTES.FORGOT_PASSWORD}`}>
              Forgot Password
            </Link>
          </div>
          <div className="actionBtnWrap">
            <CustomButton name="Login" type="submit" />
          </div>
          <div className="accountOrLoginOptWrap">
            <span className="txt">
              Don't have an account?
              <b>
                <Link className="aLink" to={`/${ROUTES.SIGNUP}`}>
                  Create
                </Link>
              </b>
            </span>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
