import React, { useContext, useEffect, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { authApi } from "../../../api";
import { getLocalAccessToken } from "../../../utils/helpers";
import CustomButton from "../../../components/CustomButton/CustomButton";
import { ROUTES } from "../../../utils/constants";
import Images from "../../../assets/img";
import "./VerifyEmail.scss";

const VerifyEmail = () => {
  const [isVerifyEmailSuccess, setIsVerifyEmailSuccess] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();
  const tokenRef = useRef<any>();
  let [searchParams, setSearchParams] = useSearchParams();

  useEffect(() => {
    const isAccessToken = getLocalAccessToken();
    if (isAccessToken) setIsLoggedIn(true);

    removeTokenFromURL();
    verifyEmail();
  }, []);

  const removeTokenFromURL = () => {
    tokenRef.current = searchParams.get("token");
    if (tokenRef.current) {
      searchParams.delete("token");
      setSearchParams(searchParams);
    }
  };

  const verifyEmail = () => {
    const token = tokenRef.current;
    authApi.verifyEmail(token).then(() => {
      setIsVerifyEmailSuccess(true);
    });
  };

  const onLoginHandler = () => {
    navigate(`/${ROUTES.LOGIN}`);
  };

  return (
    <>
      {isVerifyEmailSuccess && (
        <div className="verifyEmailPageWrapper">
          <div>
            <img src={Images.ResetPasswordSuccess} alt="delete" className="fluidImg successImg" />
            <h1 className="heading">Congratulations!</h1>
            <span className="info">Your account has been verified.</span>
            {!isLoggedIn && <CustomButton name="Login" onClick={onLoginHandler} />}
          </div>
        </div>
      )}
    </>
  );
};

export default VerifyEmail;
