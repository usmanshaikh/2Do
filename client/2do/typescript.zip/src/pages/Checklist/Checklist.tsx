import React, { useContext, useEffect, useState } from "react";
import { createSearchParams, useLocation, useNavigate } from "react-router-dom";
import { Box } from "@mui/material";
import { checklistApi } from "../../api";
import { ChecklistCard } from "../../components/Cards";
import { ROUTES } from "../../utils/constants";
import NoDataFound from "../../components/NoDataFound/NoDataFound";
import Filters from "../../components/Filters/Filters";
import "./Checklist.scss";
import { useAppSelector } from "../../hooks";

const Checklist = () => {
  const filter = useAppSelector((state) => state.filter);
  const [checklists, setChecklists] = useState<any>([]);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    filter.selectedCategory?.id && fetchChecklists();
  }, [filter]);

  const fetchChecklists = async () => {
    const payload = {
      category: filter.selectedCategory?.id,
      isCompleted: filter.selectedStatus?.isCompleted,
    };
    try {
      const res = await checklistApi.allChecklists(payload);
      setChecklists(res);
    } catch (err) {
      setChecklists([]);
    }
  };

  const onEditChecklistHandler = (data) => {
    const checklistId = data.id;
    navigate({
      pathname: `${location.pathname}/${ROUTES.ADD_EDIT_CHECKLIST}`,
      search: createSearchParams({
        checklistId,
        edit: "true",
      }).toString(),
    });
  };

  return (
    <>
      <Box className="checklistPageWrapper">
        {checklists.length ? (
          <ChecklistCard checklists={checklists} editChecklist={onEditChecklistHandler} />
        ) : (
          <NoDataFound />
        )}
      </Box>
    </>
  );
};

export default Checklist;
