import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useGlobalContext } from "../../hooks";
import { ROUTES } from "../../utils/constants";

interface RequireAuthProps {
  children: React.ReactNode; // Define children as a ReactNode
  moduleName?: string; // Optional prop for module name
}

/**
 * If the User is logged in then it will be allowed to proceed otherwise redirected to the Login page.
 * And If the user is logged in and tries to access routes that have moduleName === 'auth' then it will redirect to the Task page.
 */
const RequireAuth: React.FC<RequireAuthProps> = ({ children, moduleName }) => {
  const { authenticate } = useGlobalContext(); // Assuming you have a context for authentication
  const location = useLocation();

  // Handle redirection for the "auth" module
  if (moduleName === "auth") {
    if (authenticate) {
      return <Navigate to={`/${ROUTES.TASK}`} replace state={{ path: location.pathname }} />;
    }
    return <>{children}</>; // If not authenticated, show children
  }

  // Default authentication check
  if (authenticate) {
    return <>{children}</>; // Render children if authenticated
  }

  // Redirect to login if not authenticated
  return <Navigate to={`/${ROUTES.LOGIN}`} replace state={{ path: location.pathname }} />;
};

export default RequireAuth;
