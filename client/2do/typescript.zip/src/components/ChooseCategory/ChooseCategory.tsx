import { useEffect, useState } from "react";
import { Autocomplete, Box, TextField } from "@mui/material";
import { hideFooter, showFooter } from "../../utils/helpers";
import { categoryApi } from "../../api";
import { showSnackbar } from "../../store/slices/snackbarSlice";
import { useAppDispatch } from "../../hooks";
import "./ChooseCategory.scss";

const ChooseCategory = (props) => {
  const { isEdit, category, onChooseCategory } = props;
  const [selectedCategory, setSelectedCategory] = useState();
  const [categories, setCategories] = useState<any>();
  const dispatch = useAppDispatch();

  useEffect(() => {
    if (isEdit && category) setSelectedCategory(category);
    else getAllCategories();
  }, [category]);

  useEffect(() => {
    getAllCategories();
  }, []);

  const getAllCategories = () => {
    categoryApi
      .allCategories(true)
      .then((res) => {
        setCategories(res);
        if (!isEdit) {
          setSelectedCategory(res[0]);
          defaultCompValueIfNotEdit(res[0]);
        }
      })
      .catch((err) => dispatch(showSnackbar({ message: err.message, type: "error" })));
  };

  const handleChange = (item) => {
    const obj = { category: item.id };
    onChooseCategory(obj);
    setSelectedCategory(item.id);
  };

  const defaultCompValueIfNotEdit = (data) => {
    const obj = { category: data.id };
    onChooseCategory(obj);
  };

  return (
    <>
      {categories && (
        <div className="chooseCategoryComponentWrapper">
          <span className="commonLabel">Choose Category</span>
          <div className="autocompleteWrap">
            <Autocomplete
              disablePortal
              onChange={(event, value) => handleChange(value)}
              options={categories}
              value={selectedCategory ? selectedCategory : " "}
              defaultValue={selectedCategory}
              isOptionEqualToValue={(option, value) => option.id === value.id}
              getOptionLabel={(option: any) => {
                const match = categories.find((value) => value.id === option);
                return match ? match.categoryName : option.categoryName;
              }}
              onFocus={hideFooter}
              onBlur={showFooter}
              renderOption={(props, option) => {
                const { key, ...optionProps } = props;
                return (
                  <Box key={option.id} component="li" {...optionProps}>
                    {option.categoryName}
                  </Box>
                );
              }}
              renderInput={(params) => <TextField {...params} />}
            />
          </div>
        </div>
      )}
    </>
  );
};

export default ChooseCategory;
