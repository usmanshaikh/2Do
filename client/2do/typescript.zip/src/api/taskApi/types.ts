export interface TaskResponse {
  title: string;
  category: string | { categoryName: string; id: string };
  cardColor: string;
  dateAndTime: string;
  alert: boolean;
  isCompleted: boolean;
  type: string;
  createdBy: string;
  id: string;
}
