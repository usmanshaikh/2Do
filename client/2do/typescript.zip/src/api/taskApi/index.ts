import { axios, NO_LOADER } from "../../hooks/useAxiosInterceptor";
import { API } from "../../utils/constants";
import { NoContentResponse, TaskResponse } from "../types";

const taskApi = {
  allTasks(payload) {
    return axios.post<TaskResponse>(API.TASK.ALL, payload, NO_LOADER);
  },
  changeTaskStatus(payload, taskId) {
    return axios.patch<TaskResponse>(`${API.TASK.CHANGE_STATUS}/${taskId}`, payload, NO_LOADER);
  },
  getTask(taskId) {
    return axios.get<TaskResponse>(`${API.TASK.TASK}/${taskId}`, NO_LOADER);
  },
  createTask(payload) {
    return axios.post<TaskResponse>(`${API.TASK.CREATE}`, payload, NO_LOADER);
  },
  deleteTask(taskId) {
    return axios.delete<NoContentResponse>(`${API.TASK.TASK}/${taskId}`, NO_LOADER);
  },
  updateTask(payload, taskId) {
    return axios.patch<TaskResponse>(`${API.TASK.TASK}/${taskId}`, payload, NO_LOADER);
  },
};

export default taskApi;
