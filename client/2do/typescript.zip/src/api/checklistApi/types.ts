export interface ChecklistResponse {
  title: string;
  checklistItems: ChecklistItem[];
  category: string | { categoryName: string; id: string };
  cardColor: string;
  dateAndTime: string;
  alert: boolean;
  isCompleted: boolean;
  type: string;
  createdBy: string;
  id: string;
}

interface ChecklistItem {
  isChecked: boolean;
  text: string;
  id: string;
}
