import { axios, NO_LOADER } from "../../hooks/useAxiosInterceptor";
import { API } from "../../utils/constants";
import { NoContentResponse, ChecklistResponse } from "../types";

const checklistApi = {
  allChecklists(payload) {
    return axios.post<ChecklistResponse>(API.CHECKLIST.ALL, payload, NO_LOADER);
  },
  changeChecklistStatus(payload, checklistId) {
    return axios.patch<ChecklistResponse>(`${API.CHECKLIST.CHANGE_STATUS}/${checklistId}`, payload, NO_LOADER);
  },
  getChecklist(checklistId) {
    return axios.get<ChecklistResponse>(`${API.CHECKLIST.CHECKLIST}/${checklistId}`, NO_LOADER);
  },
  createChecklist(payload) {
    return axios.post<ChecklistResponse>(`${API.CHECKLIST.CREATE}`, payload, NO_LOADER);
  },
  deleteChecklist(checklistId) {
    return axios.delete<NoContentResponse>(`${API.CHECKLIST.CHECKLIST}/${checklistId}`, NO_LOADER);
  },
  updateChecklist(payload, checklistId) {
    return axios.patch<ChecklistResponse>(`${API.CHECKLIST.CHECKLIST}/${checklistId}`, payload, NO_LOADER);
  },
};

export default checklistApi;
