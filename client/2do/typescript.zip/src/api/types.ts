import {
  LoginResponse,
  RefreshResponse,
  RegisterResponse,
  RegisterPayload,
  LoginPayload,
  ResetPasswordPayload,
} from "./authApi/types";
import { CategoriesWithTaskAndChecklistCount, CategoryResponse } from "./categoryApi/types";
import { ChecklistResponse } from "./checklistApi/types";
import { TaskResponse } from "./taskApi/types";
import { UserResponse, StatisticReportResponse } from "./userApi/types";

type NoContentResponse = void;

export type {
  NoContentResponse,
  LoginResponse,
  RefreshResponse,
  RegisterResponse,
  CategoryResponse,
  CategoriesWithTaskAndChecklistCount,
  ChecklistResponse,
  TaskResponse,
  UserResponse,
  StatisticReportResponse,
  RegisterPayload,
  LoginPayload,
  ResetPasswordPayload,
};
