export interface CategoryResponse {
  categoryName: string;
  cardColor: string;
  createdBy: string;
  deletable: boolean;
  id: string;
}

export interface CategoriesWithTaskAndChecklistCount extends CategoryResponse {
  taskCount: number;
  checklistCount: number;
}
